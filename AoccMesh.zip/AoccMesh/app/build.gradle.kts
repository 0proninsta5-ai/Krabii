plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "iq.aocc.mesh"
    compileSdk = 34
    defaultConfig {
        applicationId = "iq.aocc.mesh"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources.excludes += setOf("META-INF/versions/**", "META-INF/*.kotlin_module") }
}
dependencies {
    implementation("com.google.android.gms:play-services-nearby:19.3.0")
    implementation("org.bouncycastle:bcprov-jdk18on:1.78.1")
}
