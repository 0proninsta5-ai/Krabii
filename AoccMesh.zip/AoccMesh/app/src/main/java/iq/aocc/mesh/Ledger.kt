package iq.aocc.mesh

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.bouncycastle.crypto.params.Ed25519PrivateKeyParameters
import org.bouncycastle.crypto.params.Ed25519PublicKeyParameters
import org.bouncycastle.crypto.signers.Ed25519Signer
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom

typealias Ev = Map<String, Any?>

val PERMISSIONS = mapOf(
    "commander" to setOf("declare_emergency", "close_zone", "order", "status", "ack"),
    "firefighter" to setOf("fire_alert", "status", "ack"),
    "medic" to setOf("medical_alert", "status", "ack"),
    "security" to setOf("security_alert", "close_zone", "status", "ack"),
    "ground_staff" to setOf("status", "ack", "report")
)
val KIND_PRIORITY = mapOf(
    "declare_emergency" to 0, "fire_alert" to 0, "medical_alert" to 0, "security_alert" to 0,
    "close_zone" to 1, "order" to 1, "status" to 2, "ack" to 2, "report" to 3
)
val ALERT_KIND = mapOf(
    "commander" to "declare_emergency", "firefighter" to "fire_alert", "medic" to "medical_alert",
    "security" to "security_alert", "ground_staff" to "report"
)

fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
fun unhex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
fun sha256(b: ByteArray) = hex(MessageDigest.getInstance("SHA-256").digest(b))

/** Canonical JSON: sorted keys, no spaces. Both phones use the same function. */
fun canon(v: Any?): String = when (v) {
    null -> "null"
    is String -> JSONObject.quote(v)
    is Number -> v.toLong().toString()
    is Map<*, *> -> v.entries.sortedBy { it.key.toString() }
        .joinToString(",", "{", "}") { JSONObject.quote(it.key.toString()) + ":" + canon(it.value) }
    else -> error("unsupported type")
}

fun toMap(o: JSONObject): Map<String, Any?> {
    val m = HashMap<String, Any?>()
    for (k in o.keys()) {
        val v = o.get(k)
        m[k] = when (v) {
            JSONObject.NULL -> null
            is JSONObject -> toMap(v)
            else -> v
        }
    }
    return m
}

fun edSign(seed: ByteArray, data: ByteArray): ByteArray {
    val s = Ed25519Signer(); s.init(true, Ed25519PrivateKeyParameters(seed, 0))
    s.update(data, 0, data.size); return s.generateSignature()
}

fun edVerify(pub: ByteArray, sig: ByteArray, data: ByteArray): Boolean = try {
    val s = Ed25519Signer(); s.init(false, Ed25519PublicKeyParameters(pub, 0))
    s.update(data, 0, data.size); s.verifySignature(sig)
} catch (e: Exception) { false }

/**
 * DEMO ONLY: the authority key is embedded so two test phones can issue themselves role certificates.
 * In production the authority private key stays on the airport admin server and issues certificates.
 */
object DemoAuthority {
    private val seed = ByteArray(32) { (it + 1).toByte() }
    val pub: String = hex(Ed25519PrivateKeyParameters(seed, 0).generatePublicKey().encoded)
    fun issue(nodeId: String, nodePub: String, role: String): Map<String, Any?> {
        val body = mapOf("node_id" to nodeId, "pub" to nodePub, "role" to role)
        return body + ("sig" to hex(edSign(seed, canon(body).toByteArray())))
    }
}

class Identity(val nodeId: String, val role: String, val seed: ByteArray) {
    val pub: String = hex(Ed25519PrivateKeyParameters(seed, 0).generatePublicKey().encoded)
    val cert: Map<String, Any?> = DemoAuthority.issue(nodeId, pub, role)
    companion object {
        fun create(role: String): Identity {
            val seed = ByteArray(32).also { SecureRandom().nextBytes(it) }
            val id = "n" + hex(ByteArray(3).also { SecureRandom().nextBytes(it) })
            return Identity(id, role, seed)
        }
    }
}

class Ledger(ctx: Context) : SQLiteOpenHelper(ctx, "aocc.db", null, 1) {
    var onChange: (() -> Unit)? = null

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE events(id TEXT PRIMARY KEY, author TEXT, seq INTEGER, prev TEXT, kind TEXT, prio INTEGER, ts INTEGER, body TEXT)")
        db.execSQL("CREATE INDEX ix_a ON events(author, seq)")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    /** Build a signed event. With enforce=false it skips the local permission check (used by the forgery test). */
    fun build(ident: Identity, kind: String, payload: String, enforce: Boolean = true): Ev {
        if (enforce && kind !in (PERMISSIONS[ident.role] ?: emptySet())) throw SecurityException("role ${ident.role} may not issue $kind")
        var prev: String? = null; var seq = 1L
        readableDatabase.rawQuery("SELECT id, seq FROM events WHERE author=? ORDER BY seq DESC LIMIT 1", arrayOf(ident.nodeId)).use {
            if (it.moveToFirst()) { prev = it.getString(0); seq = it.getLong(1) + 1 }
        }
        val body = mapOf(
            "v" to 1, "author" to ident.nodeId, "seq" to seq, "prev" to prev, "kind" to kind,
            "prio" to (KIND_PRIORITY[kind] ?: 3), "payload" to payload, "ts" to System.currentTimeMillis(), "cert" to ident.cert
        )
        val bytes = canon(body).toByteArray()
        return body + mapOf("sig" to hex(edSign(ident.seed, bytes)), "id" to sha256(bytes))
    }

    fun append(ident: Identity, kind: String, payload: String): Ev {
        val ev = build(ident, kind, payload)
        add(ev); return ev
    }

    fun check(ev: Ev): String {
        try {
            val keys = listOf("v", "author", "seq", "prev", "kind", "prio", "payload", "ts", "cert")
            val body = keys.associateWith { ev[it] }
            @Suppress("UNCHECKED_CAST") val cert = ev["cert"] as Map<String, Any?>
            val cbody = mapOf("node_id" to cert["node_id"], "pub" to cert["pub"], "role" to cert["role"])
            if (!edVerify(unhex(DemoAuthority.pub), unhex(cert["sig"] as String), canon(cbody).toByteArray())) return "bad_certificate"
            if (cert["node_id"] != ev["author"]) return "author_mismatch"
            val bytes = canon(body).toByteArray()
            if (!edVerify(unhex(cert["pub"] as String), unhex(ev["sig"] as String), bytes)) return "bad_signature"
            if (ev["id"] != sha256(bytes)) return "bad_id"
            val kind = ev["kind"] as String
            if (kind !in (PERMISSIONS[cert["role"]] ?: emptySet())) return "role_not_allowed"
            if (KIND_PRIORITY[kind] != (ev["prio"] as Number).toInt()) return "bad_priority"
            return "ok"
        } catch (e: Exception) { return "malformed" }
    }

    fun add(ev: Ev): String {
        val r = check(ev)
        if (r != "ok") return "rejected:$r"
        val db = writableDatabase
        db.rawQuery("SELECT 1 FROM events WHERE id=?", arrayOf(ev["id"] as String)).use { if (it.moveToFirst()) return "dup" }
        val cv = ContentValues().apply {
            put("id", ev["id"] as String); put("author", ev["author"] as String)
            put("seq", (ev["seq"] as Number).toLong()); put("prev", ev["prev"] as String?)
            put("kind", ev["kind"] as String); put("prio", (ev["prio"] as Number).toInt())
            put("ts", (ev["ts"] as Number).toLong()); put("body", JSONObject(ev).toString())
        }
        db.insert("events", null, cv)
        onChange?.invoke()
        return "added"
    }

    fun ids(): Set<String> {
        val out = HashSet<String>()
        readableDatabase.rawQuery("SELECT id FROM events", null).use { while (it.moveToNext()) out.add(it.getString(0)) }
        return out
    }

    /** Events the peer lacks: most urgent first, then oldest. */
    fun missingFor(peer: Set<String>): List<Ev> {
        val out = ArrayList<Ev>()
        readableDatabase.rawQuery("SELECT id, body FROM events ORDER BY prio, ts", null).use {
            while (it.moveToNext()) if (it.getString(0) !in peer) out.add(toMap(JSONObject(it.getString(1))))
        }
        return out
    }

    fun recent(limit: Int = 30): List<Ev> {
        val out = ArrayList<Ev>()
        readableDatabase.rawQuery("SELECT body FROM events ORDER BY ts DESC LIMIT $limit", null).use {
            while (it.moveToNext()) out.add(toMap(JSONObject(it.getString(0))))
        }
        return out
    }

    /** Integrity audit: gaps (deleted events), broken links, forks. */
    fun audit(): String {
        val gaps = ArrayList<String>(); var broken = 0; var forks = 0
        val authors = ArrayList<String>()
        readableDatabase.rawQuery("SELECT DISTINCT author FROM events", null).use { while (it.moveToNext()) authors.add(it.getString(0)) }
        for (a in authors) {
            val bySeq = HashMap<Long, MutableList<Pair<String, String?>>>()
            readableDatabase.rawQuery("SELECT seq, id, prev FROM events WHERE author=?", arrayOf(a)).use {
                while (it.moveToNext()) bySeq.getOrPut(it.getLong(0)) { ArrayList() }.add(it.getString(1) to it.getString(2))
            }
            val top = bySeq.keys.max()
            for (s in 1..top) if (s !in bySeq) gaps.add("$a#$s")
            for ((s, lst) in bySeq) {
                if (lst.size > 1) forks++
                for ((_, p) in lst) {
                    if (s == 1L && p != null) broken++
                    else if (s > 1 && (s - 1) in bySeq && bySeq[s - 1]!!.none { it.first == p }) broken++
                }
            }
        }
        return if (gaps.isEmpty() && broken == 0 && forks == 0) "السجل سليم" else "تنبيه: فجوات=${gaps.size} ارتباط مكسور=$broken تفرّع=$forks"
    }
}
