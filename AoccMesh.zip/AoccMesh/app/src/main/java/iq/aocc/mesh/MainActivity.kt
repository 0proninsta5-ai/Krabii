package iq.aocc.mesh

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var ledger: Ledger
    private var ident: Identity? = null
    private var mesh: MeshManager? = null
    private lateinit var status: TextView
    private lateinit var events: TextView
    private lateinit var spinner: Spinner
    private val roles = listOf("firefighter", "medic", "security", "commander", "ground_staff")
    private val roleAr = listOf("إطفاء", "إسعاف", "أمن", "قائد", "خدمات أرضية")
    private var peerCount = 0
    private val logLines = ArrayList<String>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        ledger = Ledger(this)
        ledger.onChange = { runOnUiThread { refresh() } }
        buildUi()
        refresh()
    }

    private fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text; setOnClickListener { onClick() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        root.addView(TextView(this).apply { text = "AOCC Mesh"; textSize = 22f; setTypeface(null, Typeface.BOLD) })
        root.addView(TextView(this).apply { text = "تبادل بلاغات الطوارئ بين الهواتف بدون إنترنت"; textSize = 14f })
        spinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, roleAr) }
        root.addView(spinner)
        root.addView(btn("ابدأ الشبكة بهذا الدور") { requestPermsThenStart() })
        status = TextView(this).apply { textSize = 15f; setPadding(0, 16, 0, 16) }
        root.addView(status)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(btn("حالة") { send("status", "الوضع طبيعي") }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(btn("بلاغ بحسب دوري") { send(ALERT_KIND[ident?.role] ?: "report", "بلاغ من ${ident?.role} في الموقع") }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(btn("اختبار تزوير") { forgeTest() }, LinearLayout.LayoutParams(0, -2, 1f))
        row2.addView(btn("فحص السجل") { addLog(ledger.audit()); refresh() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row2)
        root.addView(btn("فحص الجاهزية (تشخيص)") { readiness() })
        events = TextView(this).apply { textSize = 13f; setPadding(0, 16, 0, 0) }
        root.addView(ScrollView(this).apply { addView(events) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun requestPermsThenStart() {
        val perms = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            perms += listOf(Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        }
        if (Build.VERSION.SDK_INT >= 33) perms += "android.permission.NEARBY_WIFI_DEVICES"
        perms += listOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startMesh() else requestPermissions(missing.toTypedArray(), 7)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (r.any { it != PackageManager.PERMISSION_GRANTED }) addLog("بعض الصلاحيات مرفوضة، اسمح بها من إعدادات التطبيق")
        startMesh()
    }

    private fun startMesh() {
        val role = roles[spinner.selectedItemPosition]
        val prefs = getSharedPreferences("aocc", Context.MODE_PRIVATE)
        val saved = prefs.getString("role", null)
        val id = if (saved == role && prefs.getString("seed", null) != null) {
            Identity(prefs.getString("node", "")!!, role, unhex(prefs.getString("seed", "")!!))
        } else {
            Identity.create(role).also {
                prefs.edit().putString("role", role).putString("node", it.nodeId).putString("seed", hex(it.seed)).apply()
            }
        }
        ident = id
        mesh?.stop()
        mesh = MeshManager(this, ledger, "${id.nodeId}", { runOnUiThread { addLog(it) } }, { runOnUiThread { peerCount = it; refresh() } }).also { it.start() }
        refresh()
    }

    private fun send(kind: String, text: String) {
        val id = ident ?: return addLog("ابدأ الشبكة أولاً")
        try {
            val ev = ledger.append(id, kind, text)
            mesh?.broadcast(ev)
            addLog("أُرسل: $kind")
        } catch (e: SecurityException) { addLog("ممنوع محلياً: ${e.message}") }
    }

    /** Shows that forged messages are rejected by the verifier. */
    private fun forgeTest() {
        val id = ident ?: return addLog("ابدأ الشبكة أولاً")
        val tampered = ledger.build(id, "status", "رسالة أصلية").toMutableMap().also { it["payload"] = "رسالة معدّلة" }
        addLog("تعديل المحتوى: ${ledger.add(tampered)}")
        val forged = ledger.build(id, "declare_emergency", "إعلان كاذب", enforce = false)
        addLog("تجاوز الصلاحية: ${ledger.add(forged)}")
        refresh()
    }


    /** Self-check: shows exactly what is missing on this phone (permissions, Bluetooth, Wi-Fi, location, Play Services). */
    private fun readiness() {
        val lines = ArrayList<String>()
        fun mark(n: String, v: Boolean) { lines.add((if (v) "✅ " else "❌ ") + n) }
        fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
        mark("الموقع التقريبي", granted(Manifest.permission.ACCESS_COARSE_LOCATION))
        mark("الموقع الدقيق", granted(Manifest.permission.ACCESS_FINE_LOCATION))
        if (Build.VERSION.SDK_INT >= 31) {
            mark("بلوتوث: بث", granted(Manifest.permission.BLUETOOTH_ADVERTISE))
            mark("بلوتوث: اتصال", granted(Manifest.permission.BLUETOOTH_CONNECT))
            mark("بلوتوث: بحث", granted(Manifest.permission.BLUETOOTH_SCAN))
        }
        if (Build.VERSION.SDK_INT >= 33) mark("الأجهزة القريبة", granted("android.permission.NEARBY_WIFI_DEVICES"))
        val bt = try { (getSystemService(Context.BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager).adapter?.isEnabled == true } catch (e: Exception) { false }
        mark("البلوتوث مفعّل", bt)
        val wifi = try { (applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager).isWifiEnabled } catch (e: Exception) { false }
        mark("الواي فاي مفعّل", wifi)
        val loc = try { (getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager).isLocationEnabled } catch (e: Exception) { false }
        mark("خدمة الموقع (GPS) مفعّلة", loc)
        val gms = com.google.android.gms.common.GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this) == com.google.android.gms.common.ConnectionResult.SUCCESS
        mark("خدمات Google Play", gms)
        mark("أجهزة متصلة الآن: $peerCount", peerCount > 0)
        android.app.AlertDialog.Builder(this).setTitle("فحص الجاهزية").setMessage(lines.joinToString("\n")).setPositiveButton("حسناً", null).show()
    }

    private fun addLog(s: String) { logLines.add(0, s); if (logLines.size > 6) logLines.removeAt(logLines.size - 1); refresh() }

    private fun refresh() {
        status.text = (ident?.let { "الدور: ${it.role}  |  المعرّف: ${it.nodeId}\n" } ?: "لم تبدأ الشبكة\n") +
            "أجهزة متصلة: $peerCount\n" + logLines.joinToString("\n")
        events.text = ledger.recent().joinToString("\n") {
            val p = (it["prio"] as Number).toInt()
            val mark = if (p == 0) "🔴" else if (p == 1) "🟠" else "⚪"
            "$mark ${it["kind"]} | ${it["author"]} | ${it["payload"]}"
        }
    }
}
