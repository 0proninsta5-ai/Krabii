package iq.aocc.mesh

import android.content.Context
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import org.json.JSONArray
import org.json.JSONObject

/**
 * Real device-to-device mesh over Nearby Connections (Bluetooth / Wi-Fi Direct, no internet).
 * Every phone both advertises and discovers. On connect, peers swap id lists and send what the other lacks
 * (most urgent first). Newly accepted events are forwarded to all other peers (multi-hop store-and-forward).
 */
class MeshManager(
    ctx: Context,
    private val ledger: Ledger,
    private val myName: String,
    private val log: (String) -> Unit,
    private val onPeers: (Int) -> Unit
) {
    private val client = Nearby.getConnectionsClient(ctx)
    private val peers = LinkedHashSet<String>()
    private val strategy = Strategy.P2P_CLUSTER
    private val serviceId = "iq.aocc.mesh"

    fun start() {
        client.startAdvertising(myName, serviceId, connCb, AdvertisingOptions.Builder().setStrategy(strategy).build())
            .addOnFailureListener { log("فشل البث: ${it.message}") }
        client.startDiscovery(serviceId, discCb, DiscoveryOptions.Builder().setStrategy(strategy).build())
            .addOnFailureListener { log("فشل البحث: ${it.message}") }
        log("الشبكة تعمل: يبحث الجهاز عن أجهزة قريبة")
    }

    fun stop() {
        client.stopAllEndpoints(); client.stopAdvertising(); client.stopDiscovery(); peers.clear(); onPeers(0)
    }

    /** Send a locally created event to every connected peer. */
    fun broadcast(ev: Ev, except: String? = null) {
        val msg = JSONObject().put("t", "ev").put("e", JSONObject(ev)).toString()
        for (p in peers) if (p != except) client.sendPayload(p, Payload.fromBytes(msg.toByteArray()))
    }

    private val discCb = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            // Tie-break so only one side of a pair requests the connection.
            if (myName < info.endpointName) {
                client.requestConnection(myName, id, connCb).addOnFailureListener { }
            }
        }
        override fun onEndpointLost(id: String) {}
    }

    private val connCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            client.acceptConnection(id, payloadCb)
        }
        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                peers.add(id); onPeers(peers.size); log("اتصال بجهاز قريب")
                val have = JSONArray(ledger.ids().toList())
                client.sendPayload(id, Payload.fromBytes(JSONObject().put("t", "have").put("ids", have).toString().toByteArray()))
            }
        }
        override fun onDisconnected(id: String) {
            peers.remove(id); onPeers(peers.size); log("انقطع اتصال جهاز")
        }
    }

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            val m = JSONObject(String(bytes))
            when (m.getString("t")) {
                "have" -> {
                    val arr = m.getJSONArray("ids")
                    val peerIds = HashSet<String>(); for (i in 0 until arr.length()) peerIds.add(arr.getString(i))
                    for (ev in ledger.missingFor(peerIds)) {
                        val msg = JSONObject().put("t", "ev").put("e", JSONObject(ev)).toString()
                        client.sendPayload(id, Payload.fromBytes(msg.toByteArray()))
                    }
                }
                "ev" -> {
                    val ev = toMap(m.getJSONObject("e"))
                    when (val r = ledger.add(ev)) {
                        "added" -> { log("استلام حدث جديد: ${ev["kind"]}"); broadcast(ev, except = id) }
                        "dup" -> {}
                        else -> log("رُفض حدث وارد: $r")
                    }
                }
            }
        }
        override fun onPayloadTransferUpdate(id: String, update: PayloadTransferUpdate) {}
    }
}
